/* SolAi visual kit for Palam's live visuals (3 Nov 2026, "beat HeyClicky": real-time graphics that look better).
   The model writes short commands, one JSON array per line: ["node","sun","Sun",{"x":50,"y":18,"icon":"☀️"}].
   Palam hands each line over the moment it arrives (PalamKit.receive), so shapes animate in while the answer is still
   being written. Commands are data, never code: nothing the model writes is evaluated. Unknown commands, bad ids and
   bad numbers are skipped. Coordinates are percentages of the card (0–100). 3D uses the bundled three.js (r169, MIT).
   One file, no network, no dependencies; served by Palam next to the page (Mac and Windows). */
(function () {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const TONES = {
    teal: ['#7FE6D6', '#1d4b45'], amber: ['#FFC983', '#4d3a1d'], rose: ['#FF9DB0', '#4d2430'], violet: ['#B9A5FF', '#33295a'],
    sky: ['#8FCBFF', '#1d3550'], leaf: ['#A6E58B', '#2b4a20'], ink: ['#F4F1EC', '#2a302e'], red: ['#FF8A7A', '#4f231d'],
    gold: ['#F5D76E', '#4a4019']
  };
  const TONE_ORDER = ['teal', 'amber', 'sky', 'rose', 'violet', 'leaf', 'gold', 'red'];
  const css = `
  :root{color-scheme:dark}
  html,body{margin:0;height:100%;background:transparent;overflow:hidden;font-family:Inter,"Segoe UI Variable","Segoe UI",-apple-system,"SF Pro Text","Noto Sans","Noto Sans Tamil","Nirmala UI",system-ui,sans-serif}
  #pk-stage{position:fixed;inset:0;border-radius:14px;overflow:hidden}
  #pk-stage.pk-card{background:radial-gradient(120% 90% at 15% 0%,#14302b 0%,#0b1312 45%,#060808 100%)}
  #pk-stage.pk-card::before{content:"";position:absolute;inset:0;background-image:radial-gradient(rgba(127,230,214,.10) 1px,transparent 1.2px);background-size:22px 22px;mask-image:linear-gradient(#000,transparent 85%)}
  #pk-svg{position:absolute;inset:0;width:100%;height:100%}
  #pk-3d{position:absolute;inset:0}
  .pk-title{position:absolute;left:22px;top:16px;right:22px;color:#F4F1EC;font-weight:650;font-size:19px;letter-spacing:.2px;opacity:0;transform:translateY(-6px);transition:all .45s cubic-bezier(.2,.8,.2,1)}
  .pk-title small{display:block;color:#8E938F;font-weight:450;font-size:13px;margin-top:3px}
  .pk-in{opacity:1!important;transform:none!important}
  .pk-pop{transform-box:fill-box;transform-origin:center;animation:pkPop .5s cubic-bezier(.2,.9,.25,1.25) both}
  @keyframes pkPop{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:scale(1)}}
  .pk-fade{animation:pkFade .5s ease both}@keyframes pkFade{from{opacity:0}to{opacity:1}}
  .pk-draw{stroke-dasharray:var(--len);stroke-dashoffset:var(--len);animation:pkDraw .7s cubic-bezier(.4,.1,.2,1) forwards}
  @keyframes pkDraw{to{stroke-dashoffset:0}}
  .pk-grow{transform-box:fill-box;transform-origin:bottom;animation:pkGrow .7s cubic-bezier(.2,.8,.2,1) both}
  @keyframes pkGrow{from{transform:scaleY(0)}to{transform:scaleY(1)}}
  .pk-label3d{color:#F4F1EC;font-size:12.5px;font-weight:600;padding:3px 8px;border-radius:999px;background:rgba(6,8,8,.62);border:1px solid rgba(127,230,214,.35);white-space:nowrap;backdrop-filter:blur(4px)}
  .pk-note{position:absolute;left:22px;right:22px;bottom:14px;color:#C3C7C2;font-size:13px;line-height:1.45;opacity:0;transition:opacity .5s}
  @media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}.pk-draw{stroke-dasharray:none!important;stroke-dashoffset:0!important}.pk-title,.pk-note{opacity:1!important;transform:none!important}}`;

  let stage, svg, defs, layer, W = 1000, H = 640, mode = 'card', toneIndex = 0, booted = false;
  const nodes = new Map();      // id -> {x,y,w,h,cx,cy,shape,tone}
  const queue = [];             // commands waiting for boot or for three.js
  const record = [];            // every command run, for the finished page (replay)
  let three = null, threeLoading = null, t3 = null;

  // ── helpers ────────────────────────────────────────────────────────────────────────────────────────────────
  const num = (v, d) => (typeof v === 'number' && isFinite(v) ? v : d);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const px = x => clamp(num(x, 50), -10, 110) / 100 * W;
  const py = y => clamp(num(y, 50), -10, 110) / 100 * H;
  const str = (s, max) => String(s == null ? '' : s).slice(0, max || 160);
  const toneOf = t => TONES[t] ? t : TONE_ORDER[(toneIndex++) % TONE_ORDER.length];
  function el(name, attrs, parent) {
    const e = document.createElementNS(NS, name);
    for (const k in attrs) if (attrs[k] != null) e.setAttribute(k, attrs[k]);
    (parent || layer).appendChild(e);
    return e;
  }
  function wrap(text, maxChars) {
    const words = str(text, 120).split(/\s+/).flatMap(w => w.length > maxChars ? w.match(new RegExp('.{1,' + maxChars + '}', 'gu')) : [w]);
    const lines = []; let line = '';
    for (const w of words) {
      if ((line + ' ' + w).trim().length > maxChars && line) { lines.push(line); line = w; } else line = (line + ' ' + w).trim();
    }
    if (line) lines.push(line);
    return lines.slice(0, 3);
  }
  function textBlock(x, y, text, opts) {
    const o = opts || {}; const size = o.size || 15; const lines = wrap(text, o.chars || 18);
    const t = el('text', { x, y: y - (lines.length - 1) * size * 0.62, 'text-anchor': o.anchor || 'middle', 'dominant-baseline': 'middle',
      fill: o.fill || '#F4F1EC', 'font-size': size, 'font-weight': o.weight || 600 }, o.parent);
    lines.forEach((l, i) => { const s = el('tspan', { x, dy: i ? size * 1.24 : 0 }, t); s.textContent = l; });
    return t;
  }
  function drawIn(path) {
    try { const len = path.getTotalLength(); path.style.setProperty('--len', len); path.classList.add('pk-draw'); } catch (e) { /* not drawable yet */ }
  }

  // ── boot ───────────────────────────────────────────────────────────────────────────────────────────────────
  function boot(options) {
    if (booted) return; booted = true;
    const o = options || {};
    mode = o.place === 'over' ? 'over' : 'card';
    const style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);
    stage = document.createElement('div'); stage.id = 'pk-stage'; if (mode === 'card') stage.className = 'pk-card';
    document.body.appendChild(stage);
    const r = stage.getBoundingClientRect();
    W = 1000; H = Math.round(1000 * Math.max(0.3, Math.min(2, (r.height || 640) / (r.width || 1000))));
    svg = document.createElementNS(NS, 'svg'); svg.id = 'pk-svg'; svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
    svg.setAttribute('preserveAspectRatio', 'xMidYMid meet'); stage.appendChild(svg);
    defs = el('defs', {}, svg);
    // Fixed markup only (the kit's own tones); nothing the model writes ever goes this way.
    defs.innerHTML = `
      <filter id="pk-glow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="7" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <filter id="pk-shadow" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="6" stdDeviation="8" flood-color="#000" flood-opacity=".45"/></filter>
      ${Object.keys(TONES).map(k => `<linearGradient id="pk-g-${k}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${TONES[k][1]}" stop-opacity=".95"/><stop offset="1" stop-color="#0a0f0e" stop-opacity=".95"/></linearGradient>
      <marker id="pk-arrow-${k}" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="${TONES[k][0]}"/></marker>`).join('')}`;
    layer = el('g', {}, svg);
    if (Array.isArray(o.commands)) o.commands.forEach(receive);
    while (queue.length) receive(queue.shift());
  }

  // ── 2D commands ────────────────────────────────────────────────────────────────────────────────────────────
  function title(text, sub) {
    const d = document.createElement('div'); d.className = 'pk-title'; d.textContent = str(text, 90);
    if (sub) { const s = document.createElement('small'); s.textContent = str(sub, 140); d.appendChild(s); }
    stage.appendChild(d); requestAnimationFrame(() => d.classList.add('pk-in'));
  }
  function note(text) {
    const d = document.createElement('div'); d.className = 'pk-note'; d.textContent = str(text, 240);
    stage.appendChild(d); requestAnimationFrame(() => { d.style.opacity = 1; });
  }
  // Boxes are sized to the text actually drawn (measured, so Tamil, Hindi or emoji fit as well as English).
  function node(id, label, opts) {
    const o = opts || {}; const tone = toneOf(o.tone); const [c] = TONES[tone];
    const x = px(o.x), y = py(o.y); const shape = ['circle', 'pill', 'card'].includes(o.shape) ? o.shape : 'card';
    const g = el('g', { class: 'pk-pop', filter: 'url(#pk-shadow)' });
    const content = el('g', {}, g);
    if (o.icon && shape === 'circle') { const ic = el('text', { x: 0, y: 0, 'text-anchor': 'middle', 'dominant-baseline': 'middle', 'font-size': 26 }, content); ic.textContent = str(o.icon, 4); }
    const lab = textBlock(0, 0, label, { parent: content, chars: shape === 'circle' ? 12 : 18, size: 17 });
    if (o.icon && shape === 'circle') stackBelow(content.firstChild, lab, 4);
    if (o.sub) stackBelow(lab, textBlock(0, 0, o.sub, { parent: content, size: 13.5, weight: 450, fill: '#C3C7C2', chars: 24 }), 6);
    const bb = box(content); const iconW = o.icon && shape !== 'circle' ? 34 : 0;
    let w = Math.max(shape === 'pill' ? 90 : 120, bb.width + 30 + iconW), h = Math.max(48, bb.height + 26);
    if (num(o.w, 0)) w = Math.max(w, clamp(o.w, 5, 60) / 100 * W);
    if (shape === 'circle') { w = h = Math.max(96, Math.max(bb.width, bb.height) + 34); }
    content.setAttribute('transform', `translate(${x + iconW / 2 - (bb.x + bb.width / 2)},${y - (bb.y + bb.height / 2)})`);
    if (shape === 'circle') {
      g.insertBefore(mk('circle', { cx: x, cy: y, r: w / 2, fill: `url(#pk-g-${tone})`, stroke: c, 'stroke-width': 1.6 }), content);
      g.insertBefore(mk('circle', { cx: x, cy: y, r: w / 2 + 10, fill: c, opacity: .08, filter: 'url(#pk-glow)' }), g.firstChild);
    } else {
      g.insertBefore(mk('rect', { x: x - w / 2, y: y - h / 2, width: w, height: h, rx: shape === 'pill' ? h / 2 : 14, fill: `url(#pk-g-${tone})`, stroke: c, 'stroke-opacity': .85, 'stroke-width': 1.4 }), content);
      if (shape === 'card') g.insertBefore(mk('rect', { x: x - w / 2 + 12, y: y - h / 2, width: w - 24, height: 2, rx: 1, fill: c, opacity: .9 }), content);
      if (iconW) { const ic = el('text', { x: x - w / 2 + 25, y, 'text-anchor': 'middle', 'dominant-baseline': 'middle', 'font-size': 20 }, g); ic.textContent = str(o.icon, 4); }
    }
    nodes.set(str(id, 40), { x, y, w, h, shape, tone, r: w / 2 });
    return g;
  }
  function mk(name, attrs) { const e = document.createElementNS(NS, name); for (const k in attrs) if (attrs[k] != null) e.setAttribute(k, attrs[k]); return e; }
  function box(e) { try { const b = e.getBBox(); if (b.width || b.height) return b; } catch (err) { /* not laid out */ } return { x: -60, y: -12, width: 120, height: 24 }; }
  function stackBelow(above, below, gap) { const a = box(above), b = box(below); below.setAttribute('transform', `translate(0,${a.y + a.height + gap - b.y})`); }
  function edgePoint(n, tx, ty) {
    const dx = tx - n.x, dy = ty - n.y;
    if (n.shape === 'circle') { const d = Math.hypot(dx, dy) || 1; return [n.x + dx / d * (n.r + 6), n.y + dy / d * (n.r + 6)]; }
    const sx = (n.w / 2 + 6) / Math.abs(dx || 1e-6), sy = (n.h / 2 + 6) / Math.abs(dy || 1e-6); const s = Math.min(sx, sy);
    return [n.x + dx * s, n.y + dy * s];
  }
  function link(from, to, opts) {
    const o = opts || {}; const a = nodes.get(str(from, 40)), b = nodes.get(str(to, 40)); if (!a || !b) return;
    const tone = TONES[o.tone] ? o.tone : a.tone; const c = TONES[tone][0];
    const [x1, y1] = edgePoint(a, b.x, b.y), [x2, y2] = edgePoint(b, a.x, a.y);
    const bend = num(o.curve, 0) * Math.hypot(x2 - x1, y2 - y1) / 100;
    const mx = (x1 + x2) / 2 - (y2 - y1) / (Math.hypot(x2 - x1, y2 - y1) || 1) * bend, my = (y1 + y2) / 2 + (x2 - x1) / (Math.hypot(x2 - x1, y2 - y1) || 1) * bend;
    const p = el('path', { d: `M${x1},${y1} Q${mx},${my} ${x2},${y2}`, fill: 'none', stroke: c, 'stroke-width': 2.2, 'stroke-linecap': 'round',
      'stroke-dasharray': o.dashed ? '7 7' : null, 'marker-end': `url(#pk-arrow-${tone})`, 'marker-start': o.both ? `url(#pk-arrow-${tone})` : null, opacity: .9 });
    if (!o.dashed) drawIn(p);
    if (o.label) {
      // On the line when there is room; above it (beside it for upright arrows) when the gap is short.
      const len = Math.hypot(x2 - x1, y2 - y1) || 1; let lx = (x1 + 2 * mx + x2) / 4, ly = (y1 + 2 * my + y2) / 4;
      const g = el('g', { class: 'pk-fade' }); const t = textBlock(0, 0, o.label, { parent: g, size: 12.5, weight: 550, fill: '#E9E5DE', chars: 16 });
      const b = box(t); const bw = b.width + 18, bh = b.height + 8;
      if (len < (Math.abs(x2 - x1) > Math.abs(y2 - y1) ? bw : bh) + 30) {
        let nx = -(y2 - y1) / len, ny = (x2 - x1) / len; if (ny > 0 || (ny === 0 && nx < 0)) { nx = -nx; ny = -ny; }
        lx += nx * (Math.abs(nx) > .5 ? bw / 2 + 8 : 0); ly += ny * (bh / 2 + 8);
      }
      t.setAttribute('transform', `translate(${lx - (b.x + b.width / 2)},${ly - (b.y + b.height / 2)})`);
      g.insertBefore(mk('rect', { x: lx - bw / 2, y: ly - bh / 2, width: bw, height: bh, rx: bh / 2, fill: '#0b1110', stroke: c, 'stroke-opacity': .5 }), t);
    }
  }
  function flow(steps, opts) {
    const o = opts || {}; const list = Array.isArray(steps) ? steps.slice(0, 8) : []; const down = o.dir === 'down';
    const n = list.length; if (!n) return;
    const perRow = down ? n : (n <= 4 ? n : Math.ceil(n / 2)); const rows = Math.ceil(n / perRow);
    list.forEach((s, i) => {
      const step = typeof s === 'object' && s ? s : { label: s };
      const row = Math.floor(i / perRow), col = i % perRow, slot = row % 2 ? perRow - 1 - col : col;
      const x = down ? num(o.x, 50) : 8 + (slot + 0.5) / perRow * 84;
      const y = down ? 22 + (i + 0.5) / n * 70 : (rows === 1 ? num(o.y, 55) : 38 + row * 34);
      node('f' + (i + 1), step.label, { x, y, icon: step.icon, sub: step.sub, tone: step.tone || o.tone });
      if (i) link('f' + i, 'f' + (i + 1), { label: step.via });
    });
  }
  function cycle(steps, opts) {
    const o = opts || {}; const list = Array.isArray(steps) ? steps.slice(0, 8) : []; const n = list.length; if (!n) return;
    const cx = num(o.x, 50), cy = num(o.y, 56); const rx = num(o.r, 30) * (H / W) * 1.25, ry = num(o.r, 30);
    if (o.center) node('center', o.center, { x: cx, y: cy, shape: 'circle', tone: 'ink', icon: o.centerIcon });
    list.forEach((s, i) => {
      const step = typeof s === 'object' && s ? s : { label: s }; const a = -Math.PI / 2 + i / n * Math.PI * 2;
      node('c' + (i + 1), step.label, { x: cx + Math.cos(a) * rx * 1.15, y: cy + Math.sin(a) * ry, icon: step.icon, sub: step.sub, tone: step.tone });
    });
    for (let i = 1; i <= n; i++) link('c' + i, 'c' + (i % n + 1), { curve: 18, label: (list[i - 1] && list[i - 1].via) || null });
  }
  function timeline(items, opts) {
    const list = Array.isArray(items) ? items.slice(0, 8) : []; const n = list.length; if (!n) return;
    const y = py(num((opts || {}).y, 55)); const x1 = px(7), x2 = px(93);
    drawIn(el('path', { d: `M${x1},${y} L${x2},${y}`, stroke: '#7FE6D6', 'stroke-width': 2.5, 'stroke-linecap': 'round', opacity: .7 }));
    list.forEach((it, i) => {
      const item = typeof it === 'object' && it ? it : { when: '', label: it }; const x = x1 + (i + 0.5) / n * (x2 - x1);
      const tone = toneOf(item.tone); const c = TONES[tone][0]; const up = i % 2 === 0;
      const g = el('g', { class: 'pk-pop', style: `animation-delay:${i * 90}ms` });
      el('circle', { cx: x, cy: y, r: 7, fill: c, filter: 'url(#pk-glow)' }, g);
      el('path', { d: `M${x},${y + (up ? -10 : 10)} L${x},${y + (up ? -44 : 44)}`, stroke: c, 'stroke-width': 1.5, opacity: .6 }, g);
      textBlock(x, y + (up ? -62 : 62), item.when, { parent: g, size: 14, weight: 700, fill: c, chars: 14 });
      textBlock(x, y + (up ? -92 : 92), item.label, { parent: g, size: 13, weight: 500, fill: '#E9E5DE', chars: 16 });
    });
  }
  function bars(data, opts) {
    const o = opts || {}; const list = Array.isArray(data) ? data.slice(0, 12).filter(d => Array.isArray(d)) : []; if (!list.length) return;
    const max = num(o.max, Math.max(...list.map(d => num(d[1], 0)), 1));
    const left = px(9), right = px(95), top = py(24), bottom = py(84); const bw = (right - left) / list.length;
    for (let k = 0; k <= 4; k++) { const gy = bottom - (bottom - top) * k / 4; el('path', { d: `M${left},${gy} L${right},${gy}`, stroke: '#26302D', 'stroke-width': 1 }); }
    list.forEach((d, i) => {
      const v = Math.max(0, num(d[1], 0)); const h = (bottom - top) * v / max; const x = left + i * bw + bw * 0.18; const w = bw * 0.64;
      const tone = TONES[d[2]] ? d[2] : (TONES[o.tone] ? o.tone : 'teal');
      if (!defs.querySelector('#pk-bar-' + tone)) {
        const lg = el('linearGradient', { id: 'pk-bar-' + tone, x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
        el('stop', { offset: 0, 'stop-color': TONES[tone][0] }, lg); el('stop', { offset: 1, 'stop-color': TONES[tone][0], 'stop-opacity': .35 }, lg);
      }
      el('rect', { x, y: bottom - h, width: w, height: h, rx: Math.min(8, w / 4), fill: `url(#pk-bar-${tone})`, class: 'pk-grow', style: `animation-delay:${i * 70}ms` });
      const vt = el('text', { x: x + w / 2, y: bottom - h - 10, 'text-anchor': 'middle', fill: '#F4F1EC', 'font-size': 13, 'font-weight': 650, class: 'pk-fade' });
      vt.textContent = (o.prefix || '') + fmt(v) + (o.unit || '');
      textBlock(x + w / 2, bottom + 22, str(d[0], 24), { size: 12.5, weight: 500, fill: '#C3C7C2', chars: 12 });
    });
  }
  function fmt(v) { return Math.abs(v) >= 1000 ? v.toLocaleString('en-IN') : (Math.round(v * 100) / 100).toString(); }
  function lineChart(series, opts) {
    const o = opts || {}; const list = Array.isArray(series) ? series.slice(0, 4) : []; if (!list.length) return;
    const all = list.flatMap(s => (s.values || []).map(v => num(v, 0))); if (!all.length) return;
    const max = num(o.max, Math.max(...all)), min = num(o.min, Math.min(0, ...all)); const left = px(9), right = px(95), top = py(24), bottom = py(82);
    for (let k = 0; k <= 4; k++) { const gy = bottom - (bottom - top) * k / 4; el('path', { d: `M${left},${gy} L${right},${gy}`, stroke: '#26302D' }); const t = el('text', { x: left - 8, y: gy, 'text-anchor': 'end', 'dominant-baseline': 'middle', fill: '#8E938F', 'font-size': 11 }); t.textContent = fmt(min + (max - min) * k / 4); }
    const labels = Array.isArray(o.labels) ? o.labels : [];
    list.forEach((s, si) => {
      const vals = (s.values || []).map(v => num(v, 0)); const n = vals.length; if (n < 2) return; const tone = TONES[s.tone] ? s.tone : TONE_ORDER[si]; const c = TONES[tone][0];
      const pts = vals.map((v, i) => [left + i / (n - 1) * (right - left), bottom - (v - min) / ((max - min) || 1) * (bottom - top)]);
      drawIn(el('path', { d: 'M' + pts.map(p => p.join(',')).join(' L'), fill: 'none', stroke: c, 'stroke-width': 3, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }));
      pts.forEach((p, i) => el('circle', { cx: p[0], cy: p[1], r: 4, fill: c, class: 'pk-pop', style: `animation-delay:${300 + i * 40}ms` }));
      const t = el('text', { x: pts[n - 1][0] + 8, y: pts[n - 1][1], fill: c, 'font-size': 12.5, 'font-weight': 650, 'dominant-baseline': 'middle', class: 'pk-fade' }); t.textContent = str(s.name, 20);
    });
    labels.slice(0, 12).forEach((l, i) => { const n = labels.length; const t = el('text', { x: left + i / Math.max(1, n - 1) * (right - left), y: bottom + 20, 'text-anchor': 'middle', fill: '#8E938F', 'font-size': 11.5 }); t.textContent = str(l, 10); });
  }
  function donut(data, opts) {
    const o = opts || {}; const list = Array.isArray(data) ? data.slice(0, 8).filter(d => Array.isArray(d)) : []; if (!list.length) return;
    const total = list.reduce((a, d) => a + Math.max(0, num(d[1], 0)), 0) || 1; const cx = px(num(o.x, 34)), cy = py(num(o.y, 57)); const r = Math.min(W, H) * 0.24;
    let a0 = -Math.PI / 2;
    list.forEach((d, i) => {
      const v = Math.max(0, num(d[1], 0)); const a1 = a0 + v / total * Math.PI * 2; const tone = TONES[d[2]] ? d[2] : TONE_ORDER[i % TONE_ORDER.length];
      const large = a1 - a0 > Math.PI ? 1 : 0; const p = el('path', { d: `M${cx + r * Math.cos(a0)},${cy + r * Math.sin(a0)} A${r},${r} 0 ${large} 1 ${cx + r * Math.cos(a1)},${cy + r * Math.sin(a1)}`,
        fill: 'none', stroke: TONES[tone][0], 'stroke-width': r * 0.34, 'stroke-linecap': 'butt' }); drawIn(p);
      const ly = py(30) + i * 34; el('circle', { cx: px(64), cy: ly, r: 7, fill: TONES[tone][0], class: 'pk-pop' });
      const t = el('text', { x: px(64) + 18, y: ly, 'dominant-baseline': 'middle', fill: '#F4F1EC', 'font-size': 14, class: 'pk-fade' }); t.textContent = `${str(d[0], 28)}  ${Math.round(v / total * 100)}%`;
      a0 = a1;
    });
    if (o.center) textBlock(cx, cy, o.center, { size: 18, weight: 700, chars: 10 });
  }
  function compare(left, right) {
    [[left, 27, 'teal'], [right, 73, 'amber']].forEach(([side, x, tone]) => {
      const s = side && typeof side === 'object' ? side : { title: str(side) }; const c = TONES[tone][0];
      const points = Array.isArray(s.points) ? s.points.slice(0, 6) : [];
      const g = el('g', { class: 'pk-pop' }); const X = px(x), w = px(42), h = Math.min(py(74), 84 + points.length * 46), top = py(24) + (py(74) - h) / 2;
      el('rect', { x: X - w / 2, y: top, width: w, height: h, rx: 16, fill: `url(#pk-g-${tone})`, stroke: c, 'stroke-opacity': .7 }, g);
      el('rect', { x: X - w / 2 + 14, y: top, width: w - 28, height: 2.5, rx: 1, fill: c }, g);
      textBlock(X, top + 34, s.title, { parent: g, size: 18, weight: 700, fill: c, chars: 24 });
      points.forEach((p, i) => {
        const yy = top + 82 + i * 46; el('circle', { cx: X - w / 2 + 26, cy: yy, r: 4.5, fill: c }, g);
        textBlock(X - w / 2 + 42, yy, p, { parent: g, anchor: 'start', size: 14.5, weight: 500, fill: '#E9E5DE', chars: 40 });
      });
    });
  }
  function steps(items) {
    const list = Array.isArray(items) ? items.slice(0, 6) : []; const n = list.length; if (!n) return;
    list.forEach((it, i) => {
      const s = typeof it === 'object' && it ? it : { label: it }; const tone = TONES[s.tone] ? s.tone : 'teal'; const c = TONES[tone][0];
      const y = py(24) + i * (py(72) / n); const g = el('g', { class: 'pk-pop', style: `animation-delay:${i * 80}ms` });
      el('rect', { x: px(6), y: y, width: px(88), height: py(72) / n - 10, rx: 12, fill: '#0f1716', stroke: '#26302D' }, g);
      el('circle', { cx: px(6) + 30, cy: y + (py(72) / n - 10) / 2, r: 15, fill: c }, g);
      const t = el('text', { x: px(6) + 30, y: y + (py(72) / n - 10) / 2, 'text-anchor': 'middle', 'dominant-baseline': 'middle', fill: '#060808', 'font-size': 14, 'font-weight': 800 }, g); t.textContent = s.done ? '✓' : String(i + 1);
      textBlock(px(6) + 60, y + (py(72) / n - 10) / 2, s.label, { parent: g, anchor: 'start', size: 15, weight: 600, chars: 70 });
    });
  }
  function big(text, opts) {
    const o = opts || {}; const g = el('g', { class: 'pk-pop' });
    textBlock(px(50), py(num(o.y, 50)), text, { parent: g, size: num(o.size, 54), weight: 750, chars: 24, fill: '#F4F1EC' });
    if (o.sub) textBlock(px(50), py(num(o.y, 50)) + 56, o.sub, { parent: g, size: 16, weight: 450, fill: '#C3C7C2', chars: 60 });
  }
  function group(label, opts) {
    const o = opts || {}; const x = px(num(o.x, 10)), y = py(num(o.y, 20)), w = px(num(o.w, 40)), h = py(num(o.h, 40)); const tone = TONES[o.tone] ? o.tone : 'ink';
    const r = el('rect', { x, y, width: w, height: h, rx: 18, fill: TONES[tone][0], 'fill-opacity': .04, stroke: TONES[tone][0], 'stroke-opacity': .35, 'stroke-dasharray': '6 6', class: 'pk-fade' });
    layer.insertBefore(r, layer.firstChild);
    const t = el('text', { x: x + 14, y: y + 22, fill: TONES[tone][0], 'font-size': 13, 'font-weight': 650, class: 'pk-fade' }); t.textContent = str(label, 40);
  }
  // Over the screen: a ring around an area and an arrow with a label (percent of the anchored area).
  function ring(x, y, w, h, label) {
    const X = px(x), Y = py(y), Wd = Math.max(20, num(w, 10) / 100 * W), Hd = Math.max(20, num(h, 10) / 100 * H);
    const r = el('rect', { x: X, y: Y, width: Wd, height: Hd, rx: 12, fill: 'none', stroke: '#FFC983', 'stroke-width': 3.5, filter: 'url(#pk-glow)' }); drawIn(r);
    if (label) { const g = el('g', { class: 'pk-fade' }); const lines = wrap(label, 24); const bw = 22 + 8 * Math.max(...lines.map(l => l.length)); const by = Y + Hd + 14;
      el('rect', { x: X, y: by, width: bw, height: 12 + 18 * lines.length, rx: 10, fill: '#0b1110', stroke: '#FFC983' }, g); textBlock(X + bw / 2, by + 6 + 9 * lines.length, label, { parent: g, size: 14, chars: 24 }); }
  }

  // ── 3D commands (three.js, loaded on first use) ───────────────────────────────────────────────────────────
  function need3d() {
    if (three) return Promise.resolve();
    if (!threeLoading) threeLoading = Promise.all([import('./three.module.min.js'), import('./CSS2DRenderer.js'), import('./OrbitControls.js')])
      .then(([T, L, C]) => { three = T; setup3d(T, L, C); }).catch(e => { console.warn('kit: 3D unavailable', e); });
    return threeLoading;
  }
  function setup3d(T, L, C) {
    const host = document.createElement('div'); host.id = 'pk-3d'; stage.insertBefore(host, svg);
    const w = stage.clientWidth || 800, h = stage.clientHeight || 520;
    const renderer = new T.WebGLRenderer({ antialias: true, alpha: true }); renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1)); renderer.setSize(w, h);
    renderer.outputColorSpace = T.SRGBColorSpace; renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
    host.appendChild(renderer.domElement);
    const labels = new L.CSS2DRenderer(); labels.setSize(w, h); labels.domElement.style.cssText = 'position:absolute;inset:0;pointer-events:none'; host.appendChild(labels.domElement);
    const scene = new T.Scene(); const camera = new T.PerspectiveCamera(45, w / h, 0.1, 500); camera.position.set(0, 4, 12);
    scene.add(new T.HemisphereLight(0xcff7ef, 0x0a1210, 0.9));
    const key = new T.DirectionalLight(0xffffff, 2.2); key.position.set(6, 10, 8); scene.add(key);
    const rim = new T.DirectionalLight(0x7fe6d6, 1.4); rim.position.set(-8, 4, -6); scene.add(rim);
    const controls = new C.OrbitControls(camera, renderer.domElement); controls.enableDamping = true; controls.autoRotate = true; controls.autoRotateSpeed = 0.6;
    const objects = new Map(); const spinners = []; const orbiters = []; const born = [];
    const clock = new T.Clock();
    function loop() {
      const dt = Math.min(0.05, clock.getDelta()); const t = clock.elapsedTime;
      born.forEach(b => { b.k = Math.min(1, b.k + dt * 2.6); const e = 1 - Math.pow(1 - b.k, 3); b.o.scale.setScalar(Math.max(0.0001, e * b.s)); });
      spinners.forEach(s => { s.o.rotation.y += s.v * dt; });
      orbiters.forEach(o => { const c = objects.get(o.around); const a = o.a0 + t * o.v; const cx = c ? c.position.x : 0, cz = c ? c.position.z : 0, cy = c ? c.position.y : 0;
        o.o.position.set(cx + Math.cos(a) * o.r, cy + Math.sin(a) * o.r * Math.sin(o.tilt), cz + Math.sin(a) * o.r * Math.cos(o.tilt)); });
      controls.update(); renderer.render(scene, camera); labels.render(scene, camera); requestAnimationFrame(loop);
    }
    loop();
    addEventListener('resize', () => { const w2 = stage.clientWidth, h2 = stage.clientHeight; renderer.setSize(w2, h2); labels.setSize(w2, h2); camera.aspect = w2 / h2; camera.updateProjectionMatrix(); });
    t3 = { T, L, scene, camera, controls, objects, spinners, orbiters, born };
  }
  const v3 = (a, d) => Array.isArray(a) ? [num(a[0], d[0]), num(a[1], d[1]), num(a[2], d[2])] : d;
  function colorOf(c, i) { const T = t3.T; if (TONES[c]) return new T.Color(TONES[c][0]); try { return new T.Color(c || TONES[TONE_ORDER[i % TONE_ORDER.length]][0]); } catch (e) { return new T.Color('#7FE6D6'); } }
  function add3d(id, geometry, o) {
    const T = t3.T; const color = colorOf(o.color, t3.objects.size); const opacity = clamp(num(o.opacity, 1), 0.05, 1);
    const mat = o.glow ? new T.MeshBasicMaterial({ color, toneMapped: false })
      : new T.MeshStandardMaterial({ color, roughness: clamp(num(o.rough, 0.45), 0, 1), metalness: clamp(num(o.metal, 0.05), 0, 1), transparent: opacity < 1, opacity });
    const mesh = new T.Mesh(geometry, mat); const [x, y, z] = v3(o.at, [0, 0, 0]); mesh.position.set(clamp(x, -100, 100), clamp(y, -100, 100), clamp(z, -100, 100));
    geometry.computeBoundingSphere(); const radius = geometry.boundingSphere.radius;
    if (o.glow) {
      const halo = new T.Sprite(new T.SpriteMaterial({ map: glowTexture(), color, transparent: true, blending: T.AdditiveBlending, depthWrite: false, toneMapped: false }));
      halo.scale.setScalar(radius * 4.2); mesh.add(halo); mesh.add(new T.PointLight(color, 60, 0, 1.4));
    }
    if (o.label) { const d = document.createElement('div'); d.className = 'pk-label3d'; d.textContent = str(o.label, 40); const lab = new t3.L.CSS2DObject(d); lab.position.set(0, radius + 0.35, 0); mesh.add(lab); }
    t3.scene.add(mesh); t3.objects.set(str(id, 40), mesh); t3.born.push({ o: mesh, k: 0, s: 1 }); mesh.scale.setScalar(0.0001);
    return mesh;
  }
  let glowTex = null;
  function glowTexture() {
    if (glowTex) return glowTex;
    const cv = document.createElement('canvas'); cv.width = cv.height = 128; const x = cv.getContext('2d');
    const gr = x.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,.9)'); gr.addColorStop(.25, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = gr; x.fillRect(0, 0, 128, 128); glowTex = new t3.T.CanvasTexture(cv); glowTex.colorSpace = t3.T.SRGBColorSpace; return glowTex;
  }
  const C3 = {
    scene(o) { o = o || {}; const [x, y, z] = v3(o.cam, [0, 4, 12]); t3.camera.position.set(x, y, z); t3.controls.autoRotate = o.rotate !== false; if (o.stars) stars(); },
    sphere(id, o) { o = o || {}; const m = add3d(id, new t3.T.SphereGeometry(clamp(num(o.r, 1), 0.05, 20), 48, 32), o); if (o.rings) { const T = t3.T; const ring = new T.Mesh(new T.RingGeometry(num(o.r, 1) * 1.4, num(o.r, 1) * 2.1, 64), new T.MeshStandardMaterial({ color: colorOf(o.rings, 2), side: T.DoubleSide, transparent: true, opacity: .7 })); ring.rotation.x = Math.PI / 2.3; m.add(ring); } },
    box(id, o) { o = o || {}; const [w, h, d] = v3(o.size, [1, 1, 1]); add3d(id, new t3.T.BoxGeometry(clamp(w, .05, 40), clamp(h, .05, 40), clamp(d, .05, 40)), o); },
    cylinder(id, o) { o = o || {}; add3d(id, new t3.T.CylinderGeometry(clamp(num(o.r, .5), .02, 20), clamp(num(o.r, .5), .02, 20), clamp(num(o.h, 2), .05, 40), 40), o); },
    cone(id, o) { o = o || {}; add3d(id, new t3.T.ConeGeometry(clamp(num(o.r, .7), .02, 20), clamp(num(o.h, 1.6), .05, 40), 40), o); },
    torus(id, o) { o = o || {}; add3d(id, new t3.T.TorusGeometry(clamp(num(o.r, 1), .05, 20), clamp(num(o.tube, .25), .01, 5), 24, 80), o); },
    bond(a, b, o) { o = o || {}; const A = t3.objects.get(str(a, 40)), B = t3.objects.get(str(b, 40)); if (!A || !B) return; const T = t3.T;
      const len = A.position.distanceTo(B.position); const m = new T.Mesh(new T.CylinderGeometry(num(o.r, .12), num(o.r, .12), len, 16), new T.MeshStandardMaterial({ color: colorOf(o.color || 'ink', 0), roughness: .5 }));
      m.position.copy(A.position).add(B.position).multiplyScalar(.5); m.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), B.position.clone().sub(A.position).normalize()); t3.scene.add(m); t3.born.push({ o: m, k: 0, s: 1 }); },
    orbit(id, around, o) { o = o || {}; const obj = t3.objects.get(str(id, 40)); if (!obj) return; const T = t3.T; const r = clamp(num(o.r, 4), .2, 80);
      t3.orbiters.push({ o: obj, around: str(around, 40), r, v: num(o.speed, 0.5), a0: Math.random() * 6.28, tilt: num(o.tilt, 0) });
      if (o.path !== false) { const c = t3.objects.get(str(around, 40)); const path = new T.Mesh(new T.RingGeometry(r - 0.015, r + 0.015, 128), new T.MeshBasicMaterial({ color: 0x7fe6d6, transparent: true, opacity: .22, side: T.DoubleSide })); path.rotation.x = Math.PI / 2; if (c) path.position.copy(c.position); t3.scene.add(path); } },
    spin(id, speed) { const obj = t3.objects.get(str(id, 40)); if (obj) t3.spinners.push({ o: obj, v: num(speed, 0.6) }); },
    arrow3d(from, to, o) { o = o || {}; const T = t3.T; const a = new T.Vector3(...v3(from, [0, 0, 0])), b = new T.Vector3(...v3(to, [1, 0, 0])); const dir = b.clone().sub(a); const len = dir.length() || 1;
      const ar = new T.ArrowHelper(dir.normalize(), a, len, colorOf(o.color || 'amber', 1), Math.min(.6, len * .2), Math.min(.35, len * .12)); t3.scene.add(ar);
      if (o.label) { const d = document.createElement('div'); d.className = 'pk-label3d'; d.textContent = str(o.label, 30); const lab = new t3.L.CSS2DObject(d); lab.position.copy(a.clone().add(b).multiplyScalar(.5)); t3.scene.add(lab); } }
  };
  function stars() { const T = t3.T; const g = new T.BufferGeometry(); const p = new Float32Array(1500 * 3); for (let i = 0; i < p.length; i++) p[i] = (Math.random() - .5) * 160; g.setAttribute('position', new T.BufferAttribute(p, 3)); t3.scene.add(new T.Points(g, new T.PointsMaterial({ color: 0xcfe9e4, size: .12, transparent: true, opacity: .7 }))); }

  // ── dispatch ───────────────────────────────────────────────────────────────────────────────────────────────
  // "over": drawn straight over part of the screen (no card behind it), for rings and labels on what is there.
  function place(where) { mode = where === 'over' ? 'over' : 'card'; stage.classList.toggle('pk-card', mode === 'card'); }
  const C2 = { title, note, node, link, flow, cycle, timeline, bars, line: lineChart, donut, compare, steps, big, group, ring, place };
  function run(cmd) {
    if (!Array.isArray(cmd) || typeof cmd[0] !== 'string' || record.length >= 400) return;
    if (!booted) { queue.push(cmd); return; }
    const name = cmd[0], args = cmd.slice(1);
    record.push(cmd);
    try {
      if (C2[name]) return C2[name](...args);
      if (C3[name] || name === 'scene3d') { const f = name === 'scene3d' ? C3.scene : C3[name]; return need3d().then(() => { if (t3) try { f(...args); } catch (e) { console.warn('kit:', name, e); } }); }
    } catch (e) { console.warn('kit:', name, e); }
  }
  // 3D commands must run in order even though three.js loads asynchronously.
  let chain = Promise.resolve();
  function receive(line) {
    let cmd = line;
    if (typeof line === 'string') { const s = line.trim().replace(/,$/, ''); if (!s.startsWith('[')) return; try { cmd = JSON.parse(s); } catch (e) { return; } }
    if (!Array.isArray(cmd)) return;
    chain = chain.then(() => run(cmd)).catch(() => {});
  }
  window.PalamKit = { boot, receive, run, commands: () => record.slice(), version: '1.0' };
  // Messages from Palam (Windows WebView2) arrive as strings; the Mac calls PalamKit.receive directly.
  try { window.chrome && window.chrome.webview && window.chrome.webview.addEventListener('message', e => { const d = e.data; if (typeof d === 'string') d.split('\n').forEach(receive); }); } catch (e) { /* not WebView2 */ }
})();
