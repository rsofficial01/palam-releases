@echo off
rem Palam for Windows: a check for testers. It runs Palam's own self-check on this PC and saves a report and
rem pictures in a folder on your Desktop. Please don't touch the mouse or keyboard for about a minute: it opens
rem Notepad, types a test line into it and closes it again. Nothing is sent anywhere.
echo Palam is checking itself. Please don't touch the mouse or keyboard for about a minute...
set OUT=%USERPROFILE%\Desktop\Palam check
"%~dp0Palam.exe" --self-check "%OUT%"
echo.
echo Done. Please send us the folder "Palam check" on your Desktop (zip it first).
explorer "%OUT%"
pause
